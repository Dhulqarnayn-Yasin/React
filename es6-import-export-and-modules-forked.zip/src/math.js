const pi = 3.1416;

function doublePi() {
  return pi * 22;
}
function triplePi() {
  return pi * 33;
}

export default pi;
export { doublePi, triplePi };
